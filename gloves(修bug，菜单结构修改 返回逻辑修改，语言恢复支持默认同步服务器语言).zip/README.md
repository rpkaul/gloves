Modify by Bone

1. 加入seed支持
2. 皮肤语言默认与服务器同步
3. 改变菜单结构 便于使用

